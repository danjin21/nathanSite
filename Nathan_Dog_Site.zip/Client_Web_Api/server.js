

// // 인증서

// var os = require('os');
// var nodeStatic = require('node-static');
// var https = require('https');
// var socketIO = require('socket.io');


// const fs = require('fs');

// const options = {
//     key : fs.readFileSync('./private.pem'),
//     cert : fs.readFileSync('./public.pem')
// };

// var fileServer = new(nodeStatic.Server)();



// app.createServer(options, function(req,res){
//     fileServer.serve(req,res);
// }).listen(80);

// 라이브러리 불러온다.
const express = require('express');
// 객체 생성
const app = express();


// PUT DELETE 넣는 라이브러리
const methodOverride = require('method-override');
app.use(methodOverride('_method'));


// 라이브러리 불러온다.
const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({extended : true}));

// EJS  라이브러리 설치
app.set('view engine','ejs');

// evn 라이브러리 설치
require('dotenv').config()


// 비밀번호 Hash
const crypto = require('crypto');



// 사용하는것
// app.use(express.static(__dirname + '/public'));
app.use('/public', express.static('public'));

// 몽고 DB
const MongoClient = require('mongodb').MongoClient;

var db;


app.listen(process.env.PORT,function(){
    console.log('listening on 80' );    
});


// var https = require('https');
// // var PORT = process.env.PORT || 443;
// var PORT = 443;
// const fs = require('fs');

// var server = https.createServer(app);
// var options = {
//     key : fs.readFileSync('./private.pem'),
//     cert : fs.readFileSync('./public.pem')
// };

// https.createServer(options, app).listen(PORT, function(){

//     console.log('listening on 443');   
// });







// .env에 파일이 있음
MongoClient.connect(process.env.DB_URL, function(에러,client){

    if(에러){ return console.log(에러) }

    db = client.db('stem');

    // DB 접속이 완료가 된 후에 nopdejs 서버를 띄운다.
               // .env에 파일이 있음
    // app.listen(process.env.PORT,function(){
    //     console.log('listening on 80');    
    // });




})



// 로그인 준비
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const session = require('express-session');
// const { request } = require('http');

// app.use(미들웨어) => 미들웨어 : 요청-응답 중간에 뭔가 실행되는 코드
app.use(session({secret : '비밀코드', resave : true, saveUninitialized:false}));
app.use(passport.initialize());
app.use(passport.session());


app.get('/login',네비바로그인, function(요청,응답){
    응답.render('login.ejs', {IsLogin : 요청.IsLogin});

});



app.get('/contact',네비바로그인, function(요청,응답){
    응답.render('contact.ejs', {IsLogin : 요청.IsLogin});

});


app.get('/download',네비바로그인, function(요청,응답){
    응답.render('download.ejs', {IsLogin : 요청.IsLogin});

});



app.get('/fail', function(요청,응답){


    응답.send("<script>alert('비밀번호가 틀렸거나 존재하지 않는 ID 입니다. 다시한번 확인해주세요.');</script> <script>window.location=\"/login\"</script>");

    // console.log("비밀번호가 틀렸거나 아이디가 존재하지 않음");
    // 응답.redirect('/login')

});


var url = require('url');

app.post('/login', passport.authenticate('local', {
    failureRedirect : '/fail',

}), function(요청,응답){

    // console.log(요청.body.past_url);

    // var queryData = url.parse(요청.body.past_url, true).query;
    // console.log(queryData.past_url);

    // /*홈페이지로 가게*/
    // // 응답.redirect('/');
    // console.log(요청);
    // // 응답.write("<script>window.location=\"/\"</script>");
    // // 응답.send('한글되니?');
    // 응답.send("<script>alert('로그인 성공하였습니다!');</script> <script>window.location=\""+queryData.past_url+"\"</script>");
    // console.log(요청.rawHeaders.Referer);
 
    // var User = JSON.parse(요청);

    // console.log("====================" + User);
    // console.log(요청.session.past_url);

    if(요청.session.past_url == undefined)
    {
        응답.send("<script>alert('로그인 성공하였습니다! 초기 페이지로 이동합니다..');</script> <script>window.location=\""+"/"+"\"</script>");
    }
    else
    {
        응답.send("<script>alert('로그인 성공하였습니다! 이전 페이지로 이동합니다.');</script> <script>window.location=\""+요청.session.past_url+"\"</script>");
    }
  



    // 응답.send("<script>alert('로그인 성공하였습니다!');</script> <script>window.location = document.referrer; </script>");
    // 응답.send("<script>alert('로그인 성공하였습니다!');</script> <script>window.location.reload(true); history.go(-2); </script>");


 
});





                 // 미들웨어 쓰는법
app.get('/mypage', 로그인했니, 네비바로그인,  function(요청,응답){

    // console.log(요청.user);
    응답.render('mypage.ejs', {사용자 : 요청.user, IsLogin : 요청.IsLogin})
})


app.get('/logout', function(요청,응답){

    if(요청.user)
        요청.logout();

    응답.redirect('/');
})

//미들웨어
function 로그인했니(요청,응답,next){
    if(요청.user) // 요청.user가 있으면 next() (통과)
    {
        next()
    }
    else
    {
        // 응답.redirect('/login?past_url='+요청.originalUrl);
        
        // console.log(요청);
        // 요청.session.past_url = 요청.rawHeaders[7];
        for(var i=0; i<요청.rawHeaders.length; i++)
        {
            // console.log(i+":"+요청.rawHeaders[i]);
            if(요청.rawHeaders[i] == "Referer")
            {
                요청.session.past_url = 요청.rawHeaders[i+1];
            }
        }
        응답.redirect('/login');
     
    }
}



// 네비바 미들웨어

function 네비바로그인(요청,응답,next){

    if(요청.user)
        요청.IsLogin = 요청.user;    
    else
        요청.IsLogin = null;

    next()

}


var request = require('request');
const { default: axios } = require('axios');
const { cwd } = require('process');

app.get('/ranking', function(요청,응답){

        process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

        var geturl = 'http://localhost:54605/api/ranking'

        request.get({
            url:geturl
        },function(error,response,body){

        // console.log(JSON.parse(body));

        응답.send(JSON.parse(body));

        });
})



// 로그인 검사하는 부분
passport.use(new LocalStrategy({
    usernameField: 'id', // form 에 name이 id를 가진것
    passwordField: 'password', // form 에 name이 id를 가진것
    session: true, // 로그인 후 세션 저장할 것인지
    passReqToCallback: false, // 아이디,비번 말고도 다른 정보 검증시 true로 하면 req로
  }, function (/*req,*/ 입력한아이디, 입력한비번, done) {
    //console.log(입력한아이디, 입력한비번);

    process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

    const axios = require('axios');
    axios
    .post('http://localhost:54605/api/login',{
        UserId: 입력한아이디,
        Password : 입력한비번
    })
    .then(res=>{


        // console.log("res.data : "+(res.data));

        return done(null, res.data);

        // if(hashPassword == res.Password)
        //     return done(null, res);
        // else
        //     return done(null, false, { message: '비번틀렸어요' })
    })
    .catch(error=>{
            return done(null, false, { message: '로그인 실패' })
    })

  }));


// 세션을 저장시키는 코드 ( 로그인 성공시 발동 )
passport.serializeUser(function(user,done){

    // console.log('$$');
    // console.log((user));

    done(null, user.id) // 세션 데이터를 만들고 세션의 id정보를 쿠키로 보냄
})

// 마이페이지 접속시 발동 DB에서 찾는 역할
// 아이디 = user.id
passport.deserializeUser(function(아이디,done){

    // //디비에서 위에있는 user.id로 유저를 찾는다.
    // db.collection('login').findOne({ id : 아이디},function(에러, 결과){
    //     done(null, {결과})
    // });

    process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

    // console.log('아이디는요 ▽');
    // console.log(아이디);

    var geturl = 'http://localhost:54605/api/login/'+아이디;

    request.get({
        url:geturl
    },function(error,response,body){

        done(null,body);

    // console.log(JSON.parse(body));

    // 응답.send(JSON.parse(body));

    });



});




//누군가가 /pet 으로 방문을 하면
//pet 관련된 안내문을 띄워주자.app

app.get('/pet', function(요청, 응답){
    응답.send('펫용품 쇼핑할 수 있는 사이트입니다.');
});

app.get('/beauty', function(요청, 응답){
    응답.send('뷰티용품 쇼핑할 수 있는 사이트입니다.');
});

app.get('/',네비바로그인, function(요청, 응답){


    // db.collection('kodex').find().toArray(function(에러,결과){

    //     if(에러)
    //     console.log(에러);

    //     console.log(결과);
    //     응답.render('index.ejs', { posts : 결과.reverse()});
    // });

    // 응답.redirect('/board');


    process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

    var geturl = 'http://localhost:54605/api/board'

    request.get({
        url:geturl
    },function(error,response,body){

    var boards;
    
    // console.log(JSON.parse(body));
    if(body !=null)
        boards = JSON.parse(body)
        console.log(boards);



        // 보드 불러오고 나서 블로그 꺼도 가지고 온다.

        var geturl_blog = 'http://localhost:54605/api/blog'

        request.get({
            url:geturl_blog
        },function(error,response,body){
    
        var blogs;
        
        // console.log(JSON.parse(body));
        if(body !=null)
            blogs = JSON.parse(body)
    
        응답.render('index.ejs', { posts : boards, blogs : blogs, IsLogin : 요청.IsLogin}  );
    
        });





    // 응답.render('index.ejs', { posts : boards, IsLogin : 요청.IsLogin}  );

    });




    // 응답.render('index.ejs', { posts : boards, IsLogin : 요청.IsLogin});

});

app.get('/index', function(요청, 응답){

    응답.redirect('/' );

});

app.get('/upload', 로그인했니, 네비바로그인, function(요청, 응답){

    응답.render('upload.ejs', {IsLogin : 요청.IsLogin});
});


app.get('/blog', 네비바로그인, function(요청, 응답){

    // 응답.render('blog.ejs', {IsLogin : 요청.IsLogin});

    process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

    var geturl = 'http://localhost:54605/api/blog'

    request.get({
        url:geturl
    },function(error,response,body){

    var blogs;
    
    // console.log(JSON.parse(body));
    if(body !=null)
        blogs = JSON.parse(body)

    응답.render('blog.ejs', { posts : blogs, IsLogin : 요청.IsLogin}  );

    });




});


// /board 로 GET 요청으로 접속하면
// 실제 DB에 저장된 데이터들로 예쁘게 꾸며진 HTML을 보여줌.
app.get('/board',네비바로그인, function(요청, 응답){
    // 응답.sendFile(__dirname + '/board.html')

    // 디비에 저장된 post 안에 모든 데이터를 다 가져와주세요
    // 디비에 저장된 post라는 collection 안의 모든, id가 뭐인, 제목이 뭐인, 데이터를 꺼내주세요.

    process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

    var geturl = 'http://localhost:54605/api/board/page/1'

    request.get({
        url:geturl
    },function(error,response,body){

    var boards;
    
    // console.log(JSON.parse(body));
    if(body !=null)
        boards = JSON.parse(body)

    응답.render('board.ejs', { posts : boards, IsLogin : 요청.IsLogin}  );

    });


});



// /board 로 GET 요청으로 접속하면
// 실제 DB에 저장된 데이터들로 예쁘게 꾸며진 HTML을 보여줌.
app.get('/board/page/:pagenumber',네비바로그인, function(요청, 응답){
    // 응답.sendFile(__dirname + '/board.html')

    // 디비에 저장된 post 안에 모든 데이터를 다 가져와주세요
    // 디비에 저장된 post라는 collection 안의 모든, id가 뭐인, 제목이 뭐인, 데이터를 꺼내주세요.
    if(isNaN(요청.params.pagenumber) == true)
    {
        응답.redirect('/board');
        return;
    }

    process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

    var geturl = 'http://localhost:54605/api/board/page/'+요청.params.pagenumber;


    request.get({
        url:geturl
    },function(error,response,body){

    var boards;
    
    // console.log(JSON.parse(body));
    if(body !=null)
        boards = JSON.parse(body)

    console.log("boards의 사이즈 = " + boards.length);




    응답.render('board.ejs', { posts : boards, IsLogin : 요청.IsLogin}  );

    });


});





app.get('/search', (요청,응답) =>{
    console.log(요청.query.value);

    // Search index 에서 검색하는 법
    var 검색조건 = [
        {
            $search: {
            index: 'titleSearch', //님이만든인덱스명
            text: {
                query: 요청.query.value,
                path: ['제목','내용']  // 제목날짜 둘다 찾고 싶으면 ['제목', '날짜']
            }
            }
        },
        // 찾고 정렬 가능 , sort가 없으면 searchScore 이런것도 알려줌. 검색수가 많은것
        {
            $sort : {_id:1} // -1 1 오름차순,내림차순 , id or 제목, 
        },
        // {
        //     $limit : 10  // 상위 10개만가져온다
        // }
        // ,{
        //     // 프로젝터. 원하는 결과만 보여주고 싶을때
        //     // 제목은 보여주고, id는 안보여준다. score 도 갖고와줄수 있따.
        //     $project : { 제목 : 1, _id:0, score : {$meta:"searchScore"}}
        // }
    ] 

    db.collection('post').aggregate(검색조건).toArray((에러,결과)=>{
    // console.log(결과);
    응답.render('board_search.ejs', {posts : 결과} );
})
})


app.get('/board/:id', 네비바로그인, function(요청, 응답){



    if(isNaN(요청.params.id) == true)
    {
        응답.redirect('/board');
        return;
    }

    process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";


    var geturl = 'http://localhost:54605/api/board/'+요청.params.id

    request.get({
        url:geturl
    },function(error,response,body){

        // if(String(JSON.parse(body).Id =="-1"))
        //     응답.redirect('/');

        console.log("꺄오"+JSON.parse(body).id);

        if(JSON.parse(body).id == -1)
        {
            응답.redirect("/");
        }

            

        var own = 0;

        if(요청.user != null)
        {
            var User = JSON.parse(요청.user);

            // console.log("User.id = " + User.userId);
            // console.log("body.id = " + body );
            // console.log("body.id_2 = " + JSON.parse(body).userId );
            if(String(User.userId) == String(JSON.parse(body).userId))
                own = 1;
        }
        
        console.log("댓글 불러오기");
        console.log(JSON.parse(body).comments);
   
        응답.render('detail.ejs', { data : JSON.parse(body) , own : own, comment : JSON.parse(body).comments, IsLogin : 요청.IsLogin });
        
    });



    // db.collection('post').findOne({ 문서번호 : parseInt(요청.params.id)},function(에러,결과){
    //     // console.log(결과)
    //     // console.log(요청.user)
    //     var own = 0;

    //     if( 요청.user != null && String(결과.유저고유ID) == String(요청.user.결과._id))
    //         own = 1;
    //     else if ( 요청.user != null && String(결과.유저고유ID) != String(요청.user.결과._id))
    //         own = 0;

    //     db.collection('comment').find({문서번호: 요청.params.id}).toArray().then((댓글결과)=>{

    //         응답.render('detail.ejs', { data : 결과 , own : own , comment :  댓글결과});
    //     });
    // })


})



app.get('/edit/:id',로그인했니, 네비바로그인, function(요청,응답){

    process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

    var geturl = 'http://localhost:54605/api/board/'+요청.params.id

    request.get({
        url:geturl
    },function(error,response,body){

     응답.render('edit.ejs', { data : JSON.parse(body), IsLogin:요청.IsLogin } );
    });
})

app.post('/edit',로그인했니,function(요청,응답){
    
    // $set : 업데이트해주세요, 없으면 추가해주시고요.
    // 요청 중에 input 중에 name이 post_id 인 애의 값을 가져와주세요.
    // 혹은 그냥 parameter로 id를 보내줄수도 있다.


    // db.collection('post').updateOne({ 문서번호: parseInt(요청.body.post_id) },{ $set : { 제목 :요청.body.title, 내용 : 요청.body.content, 유저고유ID : 요청.user.결과._id}}, function(에러,결과){
    //     console.log('수정완료')
    //     응답.redirect('/board/'+요청.body.post_id)

    // }) 

    console.log("######");
    var User = JSON.parse(요청.user);

    process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
    const axios = require('axios')
    axios
    .put('http://localhost:54605/api/board', {
        
        Id : parseInt(요청.body.post_id),
        Title: 요청.body.title,
        Content : 요청.body.content,
        UserId : User.userId,
        Nickname :User.nickname,
 
    })
    .then(res => {
        응답.redirect('/board');
    })
    .catch(error => {
        응답.send('오류 : ' + error);
    })

    
    // 폼에 담긴 제목데이터, 날짜 데이터를 가ㅣㅈ고
    // db.collection 에다가 업데이트함
})





app.get('/register',네비바로그인, function(요청,응답){
    응답.render('register.ejs', {IsLogin : 요청.IsLogin});

});

const {OAuth2Client} = require('google-auth-library');
const client = new OAuth2Client("957637707343-c8kdhu1v2p40kso3s7q6eualivtdtluk.apps.googleusercontent.com");



app.post('/register', function(요청,응답){


    // console.log("가입하고자 하는 이메일 :" + 요청.body.email);
    // console.log("가입하고자 하는 이메일 토큰 :" + 요청.body.emailToken);


    // console.log("use checkBox :" + JSON.stringify(요청.body.useCheck));
    // console.log("info checkBox :" + 요청.body.infoCheck);

    if( 요청.body.useCheck == null || 요청.body.infoCheck == null )
    {

        응답.send("<script language=javascript>alert('이용 약관동의와 개인정보 약관동의 모두 체크해주세요!');</script><script>window.location=\"/register\"</script>");
        return;
    }

    if(요청.body.password != 요청.body.password_check)
    {

        응답.send("<script language=javascript>alert('입력하신 두 개의 비밀번호가 서로 다릅니다!');</script><script>window.location=\"/register\"</script>");
        return;
    }


    // 이메일 토큰 인증 무결성 체크
    var Email;

    process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
    const axios = require('axios')
    
    axios
    .post('https://www.googleapis.com/oauth2/v3/tokeninfo?id_token='+ 요청.body.emailToken, {

    })
    .then(res => {
        console.log("정상적인 토큰입니다." +res.data.email);
        Email = res.data.email;



        axios
        .post('http://localhost:54605/api/register', {
            UserId: 요청.body.id ,
            Password: 요청.body.password ,
            Nickname : 요청.body.nickname,
            Score: 0,
            Email : Email,
    
        })
        .then(res => {
            // 응답.redirect('/login');
            // console.log(res.data);
    
            console.log("가입 응답 : ", res.data.id );
            console.log("가입 응답 형식 : ", typeof(res.data.id) );
    
            // 응답.set("Contet-type","text/html");
            // 응답.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'});
            if(res.data.id == -1)
            {
                console.log("가입실패1");
      
                응답.send("<script>alert('ID가 중복됩니다. 다시 회원가입 해주세요.')</script><script>window.location=\"/register\"</script>");
            }
            else if(res.data.id == -2)
            {
                console.log("가입실패2");
           
                응답.send("<script>alert('닉네임이 중복됩니다. 다시 회원가입해주세요.')</script><script>window.location=\"/register\"</script>");
            }
            else if(res.data.id == -3)
            {
                console.log("가입실패3");
           
                응답.send("<script>alert('이미 인증된 이메일입니다. 이메일을 확인해주세요.')</script><script>window.location=\"/register\"</script>");
            }        
            else if(res.data.id>0)
            {
                // 응답.write("<script>window.location=\"/login\"</script>");
                응답.send("<script language=javascript>alert('회원가입 완료! 로그인해주세요!.');</script><script>window.location=\"/login\"</script>");
                console.log("가입완료");
    
            }
            
        
            // 응답.write("<script>window.location=\"/login\"</script>");
    
            // 로그인 시켜주기.
        })
        .catch(error => {
            응답.send("<script language=javascript>alert('유효하지 않은 접근입니다. 다시 시도해주세요. ');</script><script>window.location=\"/register\"</script>");
        })




        
    })
    .catch(error => {
        // 응답.send('오류 : ' + error);
        console.log("비정상적인 토큰입니다.");

        응답.send("<script language=javascript>alert('유효하지 않은 접근입니다. 다시 시도해주세요. ');</script><script>window.location=\"/register\"</script>");
    })



  
})



// 어떤 사람이 /add 라는 경로로 post 요청을 하면,
//데이터 2개(날짜,내용)를 보내주는데,
// 이때, 'post'라는 이름을 가진 collection에 두개 데이터를 저장하기.
// { 제목: '어쩌구' , 내용 : ' 어쩌구 ' }

app.post('/add', 로그인했니,function(요청,응답){


    var User = JSON.parse(요청.user);

    process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
    const axios = require('axios')
    axios
    .post('http://localhost:54605/api/board', {
        Title: 요청.body.title,
        Content : 요청.body.content,
        UserId : User.userId,
        Nickname :User.nickname,
        // DateTime : newDate(),
        TotalComment : 0,
        LikePoint : 0,
    })
    .then(res => {
        응답.redirect('/board');
    })
    .catch(error => {
        응답.send('오류 : ' + error);
    })



});



app.delete('/delete', 로그인했니,function(요청,응답){


    // console.log(요청.body);
    // // 문자를 숫자로 변환시켜줌.
    // var stringID = 요청.body._id;
    // 요청.body._id = parseInt(요청.body._id);

    // var 삭제할데이터 = { 문서번호 : 요청.body._id, 유저고유ID : 요청.user.결과._id }



    // db.collection('comment').deleteMany({문서번호: stringID}).then(()=>{

            
    //     db.collection('post').deleteOne(삭제할데이터, function(에러,결과){

    //         if(에러){console.log(에러)}
            
    //         console.log('삭제완료');
    //         응답.status(200).send({ message : '성공했습니다' }); // 응답코드 200:성공 400:실패 500:서버문제
    //     })

    // });


    var User = JSON.parse(요청.user);

    process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
    const axios = require('axios')
    axios
    .delete('http://localhost:54605/api/board/'+ 요청.body._id)
    .then(res => {
        console.log("지워졌습니다");
        // 응답.redirect('/board');
        응답.status(200).send();
        
    })
    .catch(error => {
        응답.send('오류 : ' + error);
    })

    
});


// 댓글
app.post('/comment', 로그인했니, function(요청,응답){


    var User = JSON.parse(요청.user);

    process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
    const axios = require('axios');

    console.log("댓글입력");

    axios
    .post('http://localhost:54605/api/comment', {

        BoardContentId : parseInt(요청.body.post_id),
        Content: 요청.body.post_commment,
        UserId : User.userId,
        Nickname : User.nickname,
        LikePoint : 0,

    })
    .then(res=>{
        console.log("댓글입력완료");
        응답.redirect('/board/'+요청.body.post_id);
    })
    .catch(error=>{
        응답.send('오류 : ' + error);
    })  



    // // DB에 저장해주세요
    // db.collection('post').findOne( {문서번호 : parseInt(요청.body.문서번호)} ,  function(에러,결과){



    //     var 저장할거 = {
    //         문서번호: 요청.body.문서번호,
    //         내용 : 요청.body.내용,
    //         유저고유ID : 요청.user.결과._id,
    //         유저ID : 요청.user.결과.id,
    //         닉네임 : 요청.user.결과.nickname,
    //         댓글번호 : 결과.totalComment,
    //     }
    
    //     db.collection('comment').insertOne(저장할거).then(()=>{
            


    //         db.collection('post').updateOne({문서번호 : parseInt(요청.body.문서번호)},{ $inc : {totalComment:1}},function(에러,결과){

    //         })
    
    //     }).catch(()=>{
    
    //     })
        
       
    // });


    // 응답.redirect('/');
    // console.log("앙");

});


app.get('/comment', 로그인했니, function(요청, 응답){

    // console.log("왕왕");
    // 응답.writeHead(200, {
    //   "Connection": "keep-alive",
    //   "Content-Type": "text/event-stream",
    //   "Cache-Control": "no-cache",
    // });

    // 응답.write('event: test \n'); // 보낼데이터이름 \n
    // 응답.write('data: 안녕하세요 \n\n'); // 보낼데이터 \n\n

    // db.collection('comment').find({ 문서번호 :  parseInt(요청.body.문서번호)}).toArray()
    
});





// 이메일 인증 보내기
app.post('/email', 로그인했니, function(요청,응답){


    // 토큰값 및 기간 만들고,
    // 이메일 보내고,
    // 서버 DB에 토큰값 및 기간 보내고,


    // 이메일 인증했는지 확인하고,
    // 인증된거면 이미 인증되었다고 팝업 날리고,
    // 인증안되었으면 구글 로그인하게 하고,

    // 다시 돌아오면 서버에 인증되었다고 알린다.



    console.log("뀨우웅웅");

});




// 라우터 불러오기 . 현재경로 , .. 이전경로
app.use('/shop',require('./routes/shop.js'));

app.use('/board', require('./routes/board.js'))



//========================================================= Universe 코드 관련 ======================================================//



app.get('/universe',네비바로그인, function(요청,응답){
    응답.render('universe.ejs', {IsLogin : 요청.IsLogin});

});

app.get('/universe/upload',로그인했니, 네비바로그인, function(요청,응답){
    응답.render('universe_upload.ejs', {IsLogin : 요청.IsLogin});

});

app.get('/universe/detail',네비바로그인, function(요청,응답){
    응답.render('universe_detail.ejs', {IsLogin : 요청.IsLogin});

});






// /board 로 GET 요청으로 접속하면
// 실제 DB에 저장된 데이터들로 예쁘게 꾸며진 HTML을 보여줌.
app.get('/universe/board',네비바로그인, function(요청, 응답){
    // 응답.sendFile(__dirname + '/board.html')

    // 디비에 저장된 post 안에 모든 데이터를 다 가져와주세요
    // 디비에 저장된 post라는 collection 안의 모든, id가 뭐인, 제목이 뭐인, 데이터를 꺼내주세요.

    process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

    var geturl = 'http://localhost:54605/api/board/page/1'

    request.get({
        url:geturl
    },function(error,response,body){

    var boards;
    
    // console.log(JSON.parse(body));
    if(body !=null)
        boards = JSON.parse(body)

    응답.render('universe_board.ejs', { posts : boards, IsLogin : 요청.IsLogin}  );

    });


});

