


// 파일 혹은 라이브러리 불러오기
var router = require('express').Router();





//미들웨어
function 로그인했니(요청,응답,next){
    if(요청.user) // 요청.user가 있으면 next() (통과)
    {
        next()
    }
    else
    {
        응답.send('로그인안하셨는데요?')
    }
}


// // 여기 있는 모든 router.get 에 로그인했니를 미들웨어로 쓴다는 의미
// router.use(로그인했니);

// 특정 경로에만 사용, 로그인했니만 쓰면 다쓰는거
router.use('/shirts', 로그인했니);


// require('shop.js');

// 라우터들

// router.get('/shirts', 로그인했니, function(요청, 응답){
//     응답.send('셔츠 파는 페이지입니다.');
// });

// router.get('/pants', 로그인했니,function(요청,응답){
//     응답.send('바지 파는 페이지입니다.');
// });


router.get('/shirts',  function(요청, 응답){
    응답.send('셔츠 파는 페이지입니다.');
});

router.get('/pants', function(요청,응답){
    응답.send('바지 파는 페이지입니다.');
});


// 라우터 방출

module.exports = router;



