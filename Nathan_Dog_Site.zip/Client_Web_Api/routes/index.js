// routes/index.js



module.exports = function(app)

{
    console.log("@@@2");
    const sql = require('mssql');

    

    var config = {

    user: 'SBC\jinhyoung.dan',

    password: null,

    server: '127.0.0.1',

    database: 'Ranking_Company'

        

//    options: {

//                encrypt: true // Use this if you're on Windows Azure 

//            }

    };

    

    sql.connect(config).then(pool => {

        

        // GET ALL USERS

        app.get('/api/ranking', function(req, res){

           return pool.request()

            .query('select * from GameResults')

            .then(result => {

                res.json(result.recordset);
                console.log("@@@");
                res.end();

            });

            

        });

        

        // GET SINGLE USERS BY USER_ID

        app.get('/api/users/:user_id', function(req, res){

           return pool.request()

            .input('input_parameter', sql.Int, req.params.user_id)

            .query('select * from MemberInfo where MemberID = @input_parameter')

            .then(result => {

                res.json(result.recordset);

                res.end();

            });

            

        });

        

        // GET SINGLE USERS ID BY NAME

        app.get('/api/users/userid/:name', function(req, res){

           return pool.request()

            .input('input_parameter', req.params.name)

            .query('select * from MemberInfo where Name = @input_parameter')

            .then(result => {

                res.json(result.recordset);

                res.end();

            });

            

        });

        

        // CREATE USERS

        app.post('/api/users', function(req, res){

            return pool.request()

            .input('input_parameter', req.body.name) // json body에서 name 항목을 찾아서 할당

            .query('INSERT INTO MemberInfo (Name) VALUES (@input_parameter)')

            .then(result => {

                res.json(result.recordset);

                res.end();

            });

        });

                

        // UPDATE THE USERS

        app.put('/api/users/:user_id', function(req, res){

           return pool.request()

            .input('input_parameter_user_id', sql.Int, req.params.user_id)

            .input('input_parameter_name', req.body.name)

            .query('UPDATE MemberInfo SET Name = @input_parameter_name WHERE MemberID = @input_parameter_user_id')

            .then(result => {

                res.json(result.recordset);

                res.end();

            });

        });

        // DELETE USERS

        app.delete('/api/users/:user_id', function(req, res){

            return pool.request()

            .input('input_parameter', sql.Int, req.params.user_id)

            .query('DELETE FROM MemberInfo WHERE MemberID = @input_parameter')

            .then(result => {

                res.json(result.recordset);

                res.end();

            });

        });

    });

}

