

// 파일 혹은 라이브러리 불러오기
var router = require('express').Router();


// 라우터들

router.get('/sub/sports', function(요청, 응답){
    응답.send('스포츠 게시판.');
});

router.get('/sub/game', function(요청,응답){
    응답.send('게임 게시판');
});

// 라우터 방출

module.exports = router;