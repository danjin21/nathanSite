﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SharedData.Models
{
    public class Dominate
    {
        public int Id { get; set; }
        public int Number { get; set; }
        public string UserId { get; set; }
        public string Nickname { get; set; }
        public int Cash { get; set; }
        public DateTime Date { get; set; }
        public int Check { get; set; } = 0; // 0 : 신청중, 1: 반려, 2: 완료 





    }
}
