﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SharedData.Models
{
    public class BlogContent
    {
        public int Id { get; set; }
        public int Number { get; set; }
        public string Title { get; set; }
        public string Desc { get; set; }
        public DateTime Date { get; set; }
        public string Link { get; set; }
        public string ImageLink { get; set; }

    }
}
