﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SharedData.Models;
using WebApi.Data;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BlogController : ControllerBase
    {
        ApplicationDbContext _context;

        public BlogController(ApplicationDbContext context)
        {
            _context = context;
        }


        // Read
        [HttpGet]
        public List<BlogContent> GetBlogContentList()
        {
            List<BlogContent> blogContents = _context.BlogContents
                //.OrderByDescending(item => item.Id)
                .OrderBy(item => item.Id)
                .ToList();

            return blogContents;
        }

    }
}
