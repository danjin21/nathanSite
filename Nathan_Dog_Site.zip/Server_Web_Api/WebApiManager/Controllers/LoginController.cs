﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using SharedData.Models;
using WebApi.Data;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {

		ApplicationDbContext _context;

		public LoginController(ApplicationDbContext context)
		{
			_context = context;
		}

		// Create
		[HttpPost]
		public User CheckUser([FromBody] User user)
		{
            Console.WriteLine("User Data : " + user);


			// ID 검사
			User idCheck = _context.Users
				.Where(t => t.UserId == user.UserId )
				.FirstOrDefault();

			if(idCheck == null )
				return null;

			// 비밀번호 검사
			var hasher = new PasswordHasher<string>();
			var result = hasher.VerifyHashedPassword(null, idCheck.Password, user.Password); // 로그인 성공여부 판단

			if(result.Equals(PasswordVerificationResult.Success))
            {

            }
			else
            {
				return null;
			}

			return idCheck;
		}

		// Read
		[HttpGet("{id}")]
		public User GetUser(int id)
        {
			User user = _context.Users
				.Where(user => user.Id == id)
				.FirstOrDefault();

			if (user == null)
				return null;

			return user;
        }




	}
}
