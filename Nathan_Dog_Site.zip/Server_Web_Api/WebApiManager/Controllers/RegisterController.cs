﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using SharedData.Models;
using WebApi.Data;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RegisterController : ControllerBase
    {

		ApplicationDbContext _context;

		public RegisterController(ApplicationDbContext context)
		{
			_context = context;
		}

		// Create
		[HttpPost]
		public User AddUser([FromBody] User user)
		{
			if (user == null)
				return null;

			var hasher = new PasswordHasher<string>();

			var password = user.Password;

			var hashed = hasher.HashPassword(null, password); // 회원 DB에 저장

			//var result = hasher.VerifyHashedPassword(null, hashed, "confirmPassword"); // 로그인 성공여부 판단

			// 회원 DB에 저장
			user.Password = hashed;


            Console.WriteLine("User Data : " + user);

			SiteData siteData = _context.SiteData.FirstOrDefault();

			user.Number = siteData.TotalUser + 1;

			user.Date = DateTime.Now;

			siteData.TotalUser += 1;



			User idCheck = _context.Users
				.Where(t => t.UserId == user.UserId)
				.FirstOrDefault();


			User nicknameCheck = _context.Users
				.Where(t =>  t.Nickname == user.Nickname)
				.FirstOrDefault();

			User EmailCheck = _context.Users
				.Where(t => t.Email == user.Email)
				.FirstOrDefault();


			User A = new User();
	

			if (idCheck != null)
			{
				A.Id = -1;
				return A;
			}

			if(nicknameCheck != null)
            {
				A.Id = -2;
				return A;
            }

			if(EmailCheck != null)
            {
				A.Id = -3;
				return A;
            }

			_context.Users.Add(user);
			_context.SaveChanges();

			return user;
		}

	}
}
