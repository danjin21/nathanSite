﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SharedData.Models;
using WebApi.Data;

namespace WebApi.Controllers
{
	// REST (Representational State Transfer)
	// 공식 표준 스펙은 아님
	// 원래 있던 HTTP 통신에서 기능을 '재사용'해서 데이터 송수신 규칙을 만든 것

	// CRUD
	// www.naver.com -> 현대 백화점 지하 1층
	// www.naver.com/sports/ -> 현대 백화점 지하 1층 일식당 XXX
	// verb (GET POST PUT ... )

	// Create
	// POST /api/ranking
	// -- 아이템 생성 요청 (Body에 실제 정보)

	// Read
	// GET /api/ranking
	// 모든 아이템 주세요
	// GET /api/ranking/1
	// id=1번인 아이템 주세요

	// Update
	// PUT /api/ranking (PUT 보안 문제로 웹에선 활용 X)
	// 아이템 갱신 요청 (Body에 실제 정보)

	// Delete
	// DELETE /api/ranking/1 (DELETE 보안 문제로 웹에서 활용 X)
	// id=1번인 아이템 삭제

	// ApiController 특징
	// 그냥 C# 객체를 반환해도 된다
	// null 반환하면 -> 클라에 204 Response (No Content)
	// string -> text/plain
	// 나머지 (int, bool) -> application/json

	[Route("api/[controller]")]
	[ApiController]
	public class Universe_BoardController : ControllerBase
	{
		ApplicationDbContext _context;

		public Universe_BoardController(ApplicationDbContext context)
		{
			_context = context;
		}

		// Create
		[HttpPost]
		public Universe_BoardContent AddBoardContent([FromBody] Universe_BoardContent boardContent)
		{



			SiteData siteData = _context.SiteData.FirstOrDefault();

			boardContent.Number = siteData.TotalBoard + 1;

			boardContent.Date = DateTime.Now;

			siteData.TotalBoard += 1;
		
			_context.Universe_BoardContents.Add(boardContent);
			_context.SaveChanges();

			return boardContent;
		}

		// Read
		[HttpGet]
		public List<Universe_BoardContent> GetBoardContentList()
		{
			List<Universe_BoardContent> boardContents = _context.Universe_BoardContents
				//.OrderByDescending(item => item.Id)
				.OrderBy(item => item.Id)
				.ToList();

			return boardContents;
		}

		// Read from Page
		[HttpGet("page/{pagenumber}")]
		public List<Universe_BoardContent> GetBoardContentList_page(int pagenumber)
		{
			List<Universe_BoardContent> boardContents = _context.Universe_BoardContents
				//.OrderByDescending(item => item.Id)
				.OrderBy(item => item.Id)
				.ToList();


			List<Universe_BoardContent> newboardContents = new List<Universe_BoardContent>();

			int pageListCount = 10;

			int TotalCount = boardContents.Count;

			int TotalPage = (int)(TotalCount / pageListCount) + 1;


			for(int i=0+ pageListCount*(pagenumber-1) ; i< pageListCount*pagenumber; i++)
            {
				if (i < 0)
					continue;


				if (i >= TotalCount)
					continue;

				boardContents[i].TotalPage = TotalPage;
				newboardContents.Add(boardContents[i]);
            }


			return newboardContents;
		}



		[HttpGet("{id}")]
		public Universe_BoardContent GetBoardContent(int id)
		{
			Universe_BoardContent boardContent = _context.Universe_BoardContents
						.Where(item => item.Id == id)
						.FirstOrDefault();

            List<Universe_Comment> Comments = _context.Universe_Comments
				.Where(item => item.BoardContentId == id)
                .OrderBy(item => item.Id)
                .ToList();

			if(boardContent == null)
            {
				Universe_BoardContent A = new Universe_BoardContent();
				A.Id = -1;
				return A;


			}

            //foreach (Comment p in Comments)
            //{
            //    boardContent.Comments.Add(p);
            //}

            return boardContent;
		}

		// Update
		[HttpPut]
		public bool UpdateBoardContent([FromBody] Universe_BoardContent boardContent)
		{
			var findResult = _context.Universe_BoardContents
				.Where(x => x.Id == boardContent.Id)
				.FirstOrDefault();

			if (findResult == null)
				return false;

			findResult.Title = boardContent.Title;
			findResult.Content = boardContent.Content;
			_context.SaveChanges();

			return true;
		}

		// Delete
		[HttpDelete("{id}")]
		public bool DeleteBoardContent(int id)
		{
			var findResult = _context.Universe_BoardContents
						.Where(x => x.Id == id)
						.FirstOrDefault();

			if (findResult == null)
				return false;

			// 해당 글의 댓글들을 모두 삭제한다.

			int boardId = findResult.Id;

			List<Universe_Comment> CommentsContents = _context.Universe_Comments
				.Where(x => x.BoardContentId == boardId)
				.ToList();

			foreach(Universe_Comment A in CommentsContents)
            {
				_context.Universe_Comments.Remove(A);
            }

			// 해당 글을 삭제한다.

			_context.Universe_BoardContents.Remove(findResult);
			_context.SaveChanges();

			return true;
		}
	}
}
