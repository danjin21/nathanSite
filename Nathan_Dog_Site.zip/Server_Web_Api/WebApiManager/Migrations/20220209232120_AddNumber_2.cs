﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace WebApi.Migrations
{
    public partial class AddNumber_2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "UserNumber",
                table: "Users");

            migrationBuilder.AddColumn<int>(
                name: "Number",
                table: "Users",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Number",
                table: "Users");

            migrationBuilder.AddColumn<int>(
                name: "UserNumber",
                table: "Users",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
