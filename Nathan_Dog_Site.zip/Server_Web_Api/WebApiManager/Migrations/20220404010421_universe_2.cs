﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace WebApi.Migrations
{
    public partial class universe_2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "Universe_BoardContentId",
                table: "Comments",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "Universe_BoardContents",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Number = table.Column<int>(nullable: false),
                    Title = table.Column<string>(nullable: true),
                    Content = table.Column<string>(nullable: true),
                    UserId = table.Column<string>(nullable: true),
                    Nickname = table.Column<string>(nullable: true),
                    Date = table.Column<DateTime>(nullable: false),
                    TotalComment = table.Column<int>(nullable: false),
                    LikePoint = table.Column<int>(nullable: false),
                    TotalPage = table.Column<int>(nullable: false),
                    JsonData = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Universe_BoardContents", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Universe_Comments",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    BoardContentId = table.Column<int>(nullable: false),
                    Content = table.Column<string>(nullable: true),
                    UserId = table.Column<string>(nullable: true),
                    Nickname = table.Column<string>(nullable: true),
                    Date = table.Column<DateTime>(nullable: false),
                    LikePoint = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Universe_Comments", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Comments_Universe_BoardContentId",
                table: "Comments",
                column: "Universe_BoardContentId");

            migrationBuilder.AddForeignKey(
                name: "FK_Comments_Universe_BoardContents_Universe_BoardContentId",
                table: "Comments",
                column: "Universe_BoardContentId",
                principalTable: "Universe_BoardContents",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Comments_Universe_BoardContents_Universe_BoardContentId",
                table: "Comments");

            migrationBuilder.DropTable(
                name: "Universe_BoardContents");

            migrationBuilder.DropTable(
                name: "Universe_Comments");

            migrationBuilder.DropIndex(
                name: "IX_Comments_Universe_BoardContentId",
                table: "Comments");

            migrationBuilder.DropColumn(
                name: "Universe_BoardContentId",
                table: "Comments");
        }
    }
}
